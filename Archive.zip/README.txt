finalfeat3.py contains model with best validation accuracy
finalfeat3_output_final.txt contains the bash outputs for finalfeat3.py
finalfeat1.py contains model with best logloss
other_models folder contains different py files for the many models we tried, including inspirations from kaggle discussions. 

